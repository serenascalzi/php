<?php
/**
 * This file handles landing page elements
 *
 * @package Fluida
 */

fluida_lpslider();
fluida_lpblocks();
fluida_lptext('one');
fluida_lpboxes(1);
fluida_lptext('two');
fluida_lpboxes(2);
fluida_lptext('three');
fluida_lpindex();
fluida_lptext('four');
		
// FIN