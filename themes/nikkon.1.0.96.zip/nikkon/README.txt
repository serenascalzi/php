=== Nikkon ===
Contributors: Kaira
Donate link: 
Tags: one-column, two-columns, left-sidebar, right-sidebar, grid-layout, flexible-header, custom-background, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, full-width-template, theme-options, threaded-comments, translation-ready, blog, e-commerce, photography, portfolio
Requires at least: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Nikkon is a creative multipurpose WordPress WooCommerce theme designed with a minimal, clean design which is fully responsive and fast loading. Nikkon offers multiple header layouts, multiple footer layouts and multiple page template layouts so you're able to build any type of website you need from a simple blog to a full eCommerce online store. Integrating with top Page Builders, Nikkon will make it fun building your website without and coding knowledge. Download it now... Hope you like it !! Demo - https://demo.kairaweb.com/#nikkon

== License ==

Nikkon WordPress Theme, Copyright 2016 Zack Viljoen.
Nikkon is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/copyleft/gpl.html.
Nikkon WordPress Theme is derived from Underscores WordPress Theme, Copyright 2012 Automattic http://underscores.me/ Underscores WordPress Theme is distributed under the terms of the GNU GPL.
All Javascript is located in /js/ with license headers where appropriate.

== Bundled Licenses ==

jQuery carouFredSel 6.2.1
Copyright (c) 2013 Fred Heusschen
http://en.wikipedia.org/wiki/MIT_License
http://en.wikipedia.org/wiki/GNU_General_Public_License

FontAwesome - Copyright 2012 Dave Gandy
License: MIT License
http://fontawesome.io/license/

* The Photo in screenshot.png is from unsplash.com and licensed Creative Commons 0 (CC0)
* Photos in the Nikkon demo site are from unsplash.com and licensed Creative Commons 0 (CC0)
* Photos in the Nikkon demo slider are from unsplash.com and licensed Creative Commons 0 (CC0)
Unsplash - Distributed under the terms of CC0 1.0 Universal License (Public Domain).
https://unsplash.com/license

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


Nikkon's Customizer Settings:
---------------
The theme settings are built into the WordPress Customizer using "Customizer Library" by Devin Price, situated in /customizer/.
license: GPL 2.0+
https://github.com/devinsays/customizer-library/blob/master/composer.json

The Nikkon upgrade situated in /upgrade/ displays the features that the premium version includes.
Nikkon version is licensed under GPL 2.0+

All setting are self explanatory or have notes explaining what they do or how to use the theme settings.
View the theme settings under "Appearance" -> Customize.

= Quick Specs (all measurements in pixels) =

1. Featured Images work best at a minimum of 1100 wide and 420 high.

== Changelog ==

#### 1.0.96
* Style tweaks/fixes
* Fix do_shorcode for adding shortcode slider
* Updated the language .pot file
Premium: Added setting to change Side Social Links design - Square or Round

#### 1.0.95
* Neatened Customizer Settings
* Added option to adjust/remove header phone number & icon
* Added setting to edit search bar placeholder text
* Updated the language .pot file
Premium: Added setting to remove Footer Address
Premium: Added setting for Address/extra text in the header & option to remove it

#### 1.0.94
* Style tweaks/fixes
* Updated the language .pot file
Premium: Added WooCommerce drop down cart/basket option to Nikkon headers
Premium: Added color settings for new WooCOmmerce drop down cart/basket

#### 1.0.93
* Style tweaks/fixes
* Adjusted/neatened Customizer Settings
* Added setup help link
* Updated the language .pot file
Premium: Added setting to remove all header & slider lines

#### 1.0.92
* Small theme css/html changes
* Added more help links for setup
* Updated the language .pot file
Premium: Added new setting to adjust website container width
Premium: Added Vimeo social link

#### 1.0.91
* Style tweaks/fixes
* Updated recommended plugins
* Added missing text translations
* Added compatibility for Max Mega Menu - Customize -> Plugin Support
* Updated the language .pot file
Premium: Added setting to set custom Site Tagline font
Premium: Added setting to remove header social icons
Premium: Added setting to remove footer social icons

#### 1.0.90
* Style tweaks/fixes
* Fix/Improve Default Slider responsiveness
* Updated the language .pot file
Premium: Added settings to show Site Title & Tagline with an uploaded logo
Premium: Extra setting to adjust Logo & Title/Tagline positioning

#### 1.0.89
* Style tweaks/fixes
* Updated/Improved JS for Blog Masonry Grid layout

#### 1.0.88
* Styling tweaks/fixes
* Neatened up Theme Customizer Settings
* Added setting to set the max-width for an uploaded site logo
* Updated the language .pot file
Premium: Added setting to adjust WooCommerce products shown per page
Premium: Added setting to set WooCommerce products per row
Premium: Added setting to remove WooCommerce product border
Premium: Added Single page settings to remove meta/tags/categories info

#### 1.0.87
* Fixed WooCommerce breadcrumbs overlapping on mobile
* Added styling to switch menu direction with custom CSS classes
* Added compatibility for WP Paginate for numbered pagination
* Updated WooCommerce deprecated function for ajax
* Updated the language .pot file
Premium: Added setting to remove pre text from Archive/Category list
Premium: Added setting to remove featured images on Blog list pages

#### 1.0.86
* Styling tweaks/fixes
* Fixed breadcrumb responsiveness
* Fixed blog bug - hide image space if no featured image is set

#### 1.0.85
* Updated/fixed compatibility with new WooCommerce Gallery
* Changed comment styling to accommodate for long names
Premium: Added new blog settings to display blog list summary/excerpt

#### 1.0.84
* Navigation drop down fix
Premium: Responsive styling fixes for WooCommerce & Blog Left Sidebar layouts
Premium: Added setting to adjust the default Slider duration

#### 1.0.83
* Responsive styling fixes
* Fix setting to remove Page Titles

#### 1.0.82
* Styling tweaks
* Updated the language .pot file
Premium: Added setting to set the Page Sidebar width
Premium: Added setting to set custom links for default slider posts
Premium: Added setting to set Shop List/Archive/Single pages to Left Sidebar or Full Width
Premium: Added setting to set Blog List/Archive/Single & Search page to Left Sidebar or Full Width
Premium: Added setting to add any custom social link needed

#### 1.0.81
* Styling tweaks/fixes
* Change slider to use Exceprt is Excerpt is set
* Fix search layout bug
* Updated the language .pot file

#### 1.0.80
* Added Top Bar menu drop downs
* Updated the language .pot file
Premium: Added setting to place WooCommerce cart in header top bar

#### 1.0.7
* Customizer javascript fix
* Added help for setting up Default Slider
* Styling tweaks/fixes
* Added setting to remove page titles
* Fixed search on mobile
* Added social links for Facebook & Twitter
* Updated the language .pot file
Premium: Post and Page featured images and layout settings
Premium: Added settings to customize site title and sizes
Premium: Added over 12 new social links
Premium: Add/Fix Layout Colors setting

#### 1.0.6
* Styling tweaks/fixes

#### 1.0.5
* Added ability to add a Top Bar menu
* Updated the language .pot file

#### 1.0.4
* Blog post block styling fix
* Fix blog grid layout responsive

#### 1.0.3
* Initial release.
